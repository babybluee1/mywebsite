# module1.py

def add_numbers(a, b):
    """Adds two numbers together and returns the result."""
    return a + b


def subtract_numbers(a, b):
    """Subtracts the second number from the first and returns the result."""
    return a - b
# module1.py


PI = 3.14159


def circle_area(radius):
    """Calculates the area of a circle using the constant PI."""
    return PI * radius * radius
# module1.py


def print_message(message):
    """Prints the message with a header."""
    print("### " + message + " ###")
