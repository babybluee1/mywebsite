# main.py
from my_module import MyClass, my_function


def main():
    print("Starting application...")
    my_function()  # Call some function
    obj = MyClass()  # Create an instance of a class
    obj.do_something()


if __name__ == "__main.py_":
    main()
