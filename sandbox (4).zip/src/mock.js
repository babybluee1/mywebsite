// src/api/mock.js
export const fetchMockData = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: "Hello, this is a simulated API response!",
      });
    }, 2000);
  });
};
