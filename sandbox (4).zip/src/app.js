// src/App.js
import React, { useState, useEffect } from "react";
import { fetchMockData } from "./api/mock";

const App = () => {
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchMockData().then((response) => {
      setMessage(response.data);
    });
  }, []);

  return (
    <div>
      <h1>Simulated API Data:</h1>
      <p>{message}</p>
    </div>
  );
};

export default App;
